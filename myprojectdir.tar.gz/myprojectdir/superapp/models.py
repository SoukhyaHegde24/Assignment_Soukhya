# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class SuperMan(models.Model):
    supername = models.CharField(max_length=100)
    superpower = models.CharField(max_length=300)

    def __str__(self):
       return self.supername
    def __str__(self):
       return self.superpower


class library(models.Model):
    author = models.CharField(max_length=100,default=None, null=True, blank=True)
    title = models.CharField(max_length=300,default=None, null=True, blank=True)
    publisher = models.CharField(max_length=300,default=None, null=True, blank=True)
    price = models.CharField(max_length=300,default=None, null=True, blank=True)

    def __str__(self):
       return self.author
    def __str__(self):
       return self.title
    def __str__(self):
       return self.publisher
    def __str__(self):
       return self.price




