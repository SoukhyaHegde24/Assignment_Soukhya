# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.shortcuts import loader
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
# Create your views here.
from .models import library
import datetime
import re

@csrf_exempt
def publish(request):
    # if post request came
    if request.method == 'POST':
        v1 = request.POST.get('v1')
        v2 = request.POST.get('v2')
        v3 = request.POST.get('v3')
        v4 = request.POST.get('v4')



        library_obj = library(author=v1, title=v2, publisher=v3, price=v4)
        library_obj.save()

        # adding the values in a context variable

        all = library.objects.all()

        context = {
            'author': v1,
            'title': v2,
            'publisher': v3,
            'price': v4,
            'all': all,

        }
        # getting our showdata template
        template = loader.get_template('superapp/show.html')

        # returing the template
        return HttpResponse(template.render(context, request))

    else:
        # if post request is not true
        # returing the form template
        template = loader.get_template('superapp/index.html')
        return HttpResponse(template.render())


@csrf_exempt
def gettoday(request):
    # if post request came

    today_date = datetime.datetime.now().date()
    today_time = datetime.datetime.now().time()
    months_of_year = ['Jan','Feb','Mar','April','May','June','July','Aug','Sept','Oct','Nov','Dec']
    context = {
        'today_date' : today_date,
        'today_time' : today_time,
        'months' : months_of_year,
    }
    # getting our showdata template
    template = loader.get_template('superapp/today.html')

    # returing the template
    return HttpResponse(template.render(context, request))


@csrf_exempt
def getall(request):
    # if post request came

    all = library.objects.all()

    matched = []
    for al in all:

        r = re.findall(r"^B",al.author)
        if len(r)>0:
            matched.append(al)

    context = {
        'all' : all,
        'matched' : matched,
    }
    # getting our showdata template
    template = loader.get_template('superapp/all.html')

    # returing the template
    return HttpResponse(template.render(context, request))

def search(request):

    all = library.objects.all()

    matched = []
    for al in all:

 #       parameters = urllib.urlencode({'param1': '7', 'param2': 'seven'})
        str = request.GET.get('key')

        r = re.findall(r"^"+str,al.author)
        if len(r)>0:
            matched.append(al)

    context = {
        'all' : all,
        'matched' : matched,
    }
    # getting our showdata template
    template = loader.get_template('superapp/search.html')

    # returing the template
    return HttpResponse(template.render(context, request))


@csrf_exempt
def superfunc(request):
    # if post request came
    if request.method == 'POST':
        v1 = request.POST.get('supername')
        v2 = request.POST.get('superpower')

        data = library(author=v1,superpower=v2)
        data.save()

        # adding the values in a context variable
        context = {
            'super1': v1,
            'super2': v2,
        }
        # getting our showdata template
        template = loader.get_template('superapp/show.html')

        # returing the template
        return HttpResponse(template.render(context, request))

    else:
        # if post request is not true
        # returing the form template
        template = loader.get_template('superapp/index.html')
        return HttpResponse(template.render())

