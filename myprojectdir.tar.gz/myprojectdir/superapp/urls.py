from django.conf.urls import url

from . import views

app_name = 'superapp'

urlpatterns = [

    url(r'^$', views.superfunc, name='index'),
    url('paperpublish/', views.publish, name='show'),
    url('today/', views.gettoday, name='today'),
    url('all/', views.getall, name='papers'),
    url('search/', views.getall, name='serach'),
]
